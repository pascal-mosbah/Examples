
#include <iostream>
#include <thread>
#include <chrono>

#include "Customer.hpp"

#include <boost/asio.hpp>

using namespace boost::asio;
using ip::tcp;

using namespace std::chrono_literals;

void receive_data_through_socket(tcp::socket &socket, Customer &customer)
{
    boost::system::error_code error;
    boost::asio::streambuf buf;
    boost::asio::read(socket, buf, error);
    if (error && error != boost::asio::error::eof)
    {
        std::cout << "Read error: " << error.message() << "\n";
        return;
    }

    std::istream is(&buf);
    boost::archive::text_iarchive ia(is);
    ia >> customer;
}

void send_data_through_socket(tcp::socket &socket, Customer &customer)
{
    boost::asio::streambuf buf;
    std::ostream os(&buf);
    boost::archive::text_oarchive ar(os);
    ar << customer;
    boost::system::error_code error;
    boost::asio::write(socket, buf);
    if (!error)
    {
        std::cout << "Client sent !" << std::endl;
    }
    else
    {
        std::cout << "Client sent failed: " << error.message() << std::endl;
    }
}

void client_server_client(Customer &customer)
{

    std::this_thread::sleep_for(1s);

    boost::asio::io_service io_service;
    // socket creation
    tcp::socket socket(io_service);
    // connection
    socket.connect(tcp::endpoint(boost::asio::ip::address::from_string("127.0.0.1"), 1234));

    send_data_through_socket(socket, customer);

        std::this_thread::sleep_for(10s);

    read_message(socket);

    // std::this_thread::sleep_for(3s);
    // receive_data_through_socket(socket, customer);
}

int main(int argc, char *argv[])
{
    Customer customer1(1001, "Tartempion1",
                       {10000, 10001});

    std::thread server(client_server_server);

    std::this_thread::sleep_for(2s);

    client_server_client(customer1);
    server.join();

    exit(EXIT_SUCCESS);
}
